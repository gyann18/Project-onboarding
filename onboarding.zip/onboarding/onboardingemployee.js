import React from 'react';

const Step1 = ({ nextStep }) => {
  return (
    <div>
      <h2>Step 1: Welcome</h2>
      <p>Welcome to the onboarding process!</p>
      <button onClick={nextStep}>Next</button>
    </div>
  );
};

export default Step1;
